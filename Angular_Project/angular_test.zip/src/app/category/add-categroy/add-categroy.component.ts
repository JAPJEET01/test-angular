import { Component } from '@angular/core';

@Component({
  selector: 'app-add-categroy',
  templateUrl: './add-categroy.component.html',
  styleUrls: ['./add-categroy.component.css']
})
export class AddCategroyComponent {

}
